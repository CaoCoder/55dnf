<?php
date_default_timezone_set("PRC");
error_reporting(E_ALL ^ E_DEPRECATED);
header("Content-Type: text/html;charset=utf-8");

define('DBHOST','127.0.0.1');
define('DBPORT',3306);
define('DBUSER','root');
define('DBPASS','123456');
define('DBNAME','game');
define('DBNAMEA','release_adb');
define('DBNAMEB','release_ddb');

