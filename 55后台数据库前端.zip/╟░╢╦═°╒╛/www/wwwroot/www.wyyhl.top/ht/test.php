<?php
$user = $_POST['c1'];
$item = $_POST['c2'];
$num = $_POST['c3'];
$code = $_POST['c4'];
$gm = '123123';
$data = $item . '@' . $num;
$url = 'http://127.0.0.1:20001/gm/sendItems';
if($gm != $code){
                $data = array('code'=>200,'message'=>"你想干啥嘛！");
				exit(json_encode($data));	
}


            $postFields = array(
                'userName' => $user,
				'title' => 'DNF手游',
				'massage' => 'GM发福利',
                'items' => $data
            );

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);
            curl_close($ch);        

            if($response === '"SUCCESS"'){
                $data = array('code'=>200,'message'=>"成功！");
				exit(json_encode($data));
	
            }else {
                $data = array('code'=>200,'message'=>"充值失败！");
				exit(json_encode($data));
		
            } 