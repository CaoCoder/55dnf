<?php
error_reporting(0);
header("Content-type: text/html; charset=utf-8");
ini_set('date.timezone','Asia/Shanghai');
session_start();
//==================================================
$key='welcome to 90175.com 2022 Powered by QQ9851320';
//==================================================
//仅供本地学习娱乐使用
//仅供本地学习娱乐使用
//仅供本地学习娱乐使用
//==================================================

    $_SESSION['gmbt'] ='QCYMWCOM';
	$gmbt = '韩版DNF';  //标题	
	$gmcodeb = '90175.com';  //GM码
	$gmkey="e5bd801b364d652babeacaa1b14dd2bd";
	$sa="%E7%89%88%E6%9C%AC%202021%20Powered%20by%20%E4%B9%9D%E9%9B%B6%E4%B8%80%E8%B5%B7%E7%8E%A9%20QQ9851320%20%E5%8B%BF%E6%94%B9";
	$xname="游戏账号";// 界面显示的 授权游戏账号 这里方便统一
	$disables=array();
	$vip='dnf_';
	$frefresh=3;//防刷新间隔 秒
    $title   = 'GM';
    $content = '尊贵的DNF勇士，这是您的福利！请查收！！！';
	$yzfvip=array(//自行修改VIP权限
	'1'=>'VIP1只充值',   
	'2'=>'VIP2充值+邮件',
	);		

	$quarr=array(
		'1'=>array(
			'name'=>'海纳1区',
			'db_ip'=>'127.0.0.1',
			'db_port'=>3306,
			'db_name'=>'login',
			'db_user'=>'root',
			'db_pswd'=>'123456',
			'gm_url'=>'http://127.0.0.1:20001/gm/sendItems', //改自己的邮件接口
            'hidde'=>false
		),
      	'2'=>array(
			'name'=>'海纳2区',
			'db_ip'=>'127.0.0.1',
			'db_port'=>3306,
			'db_name'=>'login',
			'db_user'=>'root',
			'db_pswd'=>'123456',
			'gm_url'=>'http://127.0.0.1:20001/gm/sendItems', //改自己的邮件接口
            'hidde'=>true
		),      
	);

include_once 'conn.php';	