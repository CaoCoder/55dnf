<?php

function getHexGuid($a){
	$r='';
	while($a){
		$r = sprintf("%02X%s",bcmod($a,256),$r);
		$a = bcdiv($a,256);
	}
	return $r;
}

function mima($data,$key) {
    $signbb = md5($data.$key);
    return $signbb;
}
//更多资源下载 九  零一起  玩www.9 01 75.co  m
/*以下函数用于替换exit*/
function exit_notice($message){
		$return=array(
			'errcode'=>1,
			'info'=>$message,
		);
		exit(json_encode($return));
		
}

function exit_notice_old($message,$errno,$other=array()){
	if(is_array($message)) $message =json_encode($message,JSON_UNESCAPED_UNICODE);
	$rtn['message']=$message;
	$rtn['errno']=$errno;
	if(count($other)>0){
		foreach($other as $k=>$v){
			$rtn[$k]=$v;
		}
	}
	exit(json_encode($rtn,JSON_UNESCAPED_UNICODE));
}

	function get($url){
		$ch = curl_init(); 
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); 
		curl_setopt($ch, CURLOPT_HEADER, 1); 
		curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		$output = curl_exec($ch);
		$errorCode = curl_errno($ch);
		curl_close($ch);
		if(0 !== $errorCode){
			return false;
		}
		return $output;
	}

	function post($url,$postdata,$headers=array()){
		$ch = curl_init(); 
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); 
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_POST, 1);  
		if(sizeof($headers)>0){ 
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		}
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postdata)); 
		curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		$output = curl_exec($ch);
		$errorCode = curl_errno($ch);
		curl_close($ch);
		if(0 !== $errorCode){
			return false;
		}
		return $output;
	}

		function login(){
		global $WEB;
		$re=get($WEB['WEB_BASE'].'login.html');
		if($re){
			list($header, $body) = explode("\r\n\r\n", $re);
			preg_match("/name\=\"\_\_token\_\_\" value\=\"([^\"]*)/i", $re, $matches);
			$token=$matches[1];
			preg_match("/set\-cookie:([^\r\n]*)/i", $header, $matches);
			$cookie = trim(explode(';', $matches[1])[0]);
			$post=array(
				'__token__'=>$token,
				'username'=>$WEB['WEB_ADMIN'],
				'password'=>$WEB['WEB_PSWD'],
				'vercode'=>'abc'
			);
			$headers=array(
				'Cookie:'. $cookie,
				'Content-Type: application/x-www-form-urlencoded; charset=utf-8'
			);
			$re=post($WEB['WEB_BASE'].'Login',$post,$headers);
			
			//return $re;
			if(strpos($re,'登录成功')){
				return $cookie;
			}else{
				return '';
			}
		}else{
			return '';
		}
	}
	
	
	function login_new($gmurl,$gmuser,$gmpwd){
		//global $WEB;
		$re=get($gmurl.'login.html');
		if($re){
			list($header, $body) = explode("\r\n\r\n", $re);
			preg_match("/name\=\"\_\_token\_\_\" value\=\"([^\"]*)/i", $re, $matches);
			$token=$matches[1];
			preg_match("/set\-cookie:([^\r\n]*)/i", $header, $matches);
			$cookie = trim(explode(';', $matches[1])[0]);
			$post=array(
				'__token__'=>$token,
				'username'=>$gmuser,
				'password'=>$gmpwd,
				'vercode'=>'abc'
			);
			$headers=array(
				'Cookie:'. $cookie,
				'Content-Type: application/x-www-form-urlencoded; charset=utf-8'
			);
			$re=post($gmurl.'Login',$post,$headers);
			
			if(strpos($re,'登录成功')){
				return $cookie;
			}else{
				return '';
			}
		}else{
			return '';
		}
	}
	

function postData($url, $data,$cookie_file)  {  
    $ch = curl_init();  
    $timeout = 300;   
    curl_setopt($ch, CURLOPT_URL, $url);  
    curl_setopt($ch, CURLOPT_POST, true);  
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);  
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch ,CURLOPT_COOKIEFILE,$cookie_file);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    $handles = curl_exec($ch);  
    curl_close($ch);  
    return $handles;  
}

