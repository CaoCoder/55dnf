<?php
include 'config.php';
//session_start();
//error_reporting(0);
//header("Content-type: text/html; charset=utf-8");
//ini_set('date.timezone','Asia/Shanghai');
$time=time();
if(abs($time-(int)$_SESSION['lasttime'])<$frefresh){exit_notice('刷太快了!!!',0);}
$_SESSION['lasttime']=$time;
if($_POST){
	if(md5($key)!=$gmkey){$eff = urldecode($sa);exit_notice($eff,0);}
	//include 'config.php';
	$quid=$_SESSION["quid"];
	if($quid==''){exit_notice('区号错误!!!',0);}
	$qu=$quarr[$quid];
	if(!$qu['db_ip']){exit_notice('区配置不存在!!!',0);}
	$uid=$_SESSION["uid"];	
	if($uid==''){exit_notice('账号错误!!!',0);}
	$viplevel=$_SESSION["vip"];
	$act=$_POST['type'];
	$url = $qu['gm_url'];
	$db_name=$qu['db_name'];

    $conn = new mysqli($qu['db_ip'], $qu['db_user'], $qu['db_pswd']);
	if ($conn->connect_errno) exit_notice('数据库连接失败!!!',1);

    $rid = $conn->query("SELECT * FROM $db_name.t_account WHERE userID = '$uid' LIMIT 1")->fetch_assoc()['id'];
    if ($rid==''){exit_notice('账号不存在!!!'.$rid,0);}

//    $conn = @mysql_connect($qu['db_ip'], $qu['db_user'], $qu['db_pswd']);
//	if(!$conn){exit_notice('数据库连接失败!!!',0);}

//	@mysql_query("set names utf8");	
//	mysql_select_db($qu['db_name'], $conn);
//	$sql = "select * from `t_account` where  `userID` = '$uid' limit 1";
//	$res = mysql_query($sql, $conn);
//    $row = mysql_fetch_array($res);
//	if($row['userID']==''){mysql_close($conn);exit_notice('角色不存在!!!'.$uid,0);}

	switch($act){
	case 'charge':// 暂无充值

	$num = intval($_POST['num']);
	if(!$num){exit_notice('充值数量错误!!!',0);}

	if($res){
    exit_notice('充值成功！'.$uid,0);
    }else{
    exit_notice('充值失败！'.$uid,0);
    }
    break;

    case 'mail':
    if($viplevel<2){exit_notice('物品后台权限未开通！！！',1);}		

    $itemid=intval($_POST['item']);
    $itemnum = intval($_POST['num']);
    $max=99999;
    if(in_array($itemid,$disables)){exit_notice('此物品您无权发送',1);	}	
    if($itemnum==0 || $itemnum>$max) {exit_notice('物品数量错误,最大支持：'.$max,1);	}
    $itemdata = $itemid . '@' . $itemnum;
    $postFields = array(
    'gmCode' => $gmcodeb,
    'userName' => $uid,
    'title' => $title,
    'massage' => $content,
    'items' => $itemdata
    );
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    if($response === '"SUCCESS"'){
    exit_notice('邮件发送成功！',1);
    }
    exit_notice('邮件发送失败！',1);
    break;

		default:
			$return=array(
				'errcode'=>1,
				'info'=>'数据错误',
			);
			exit(json_encode($return));
			break;
	}
}else{
	$return=array(
		'errcode'=>1,
		'info'=>'提交错误',
	);
	exit(json_encode($return));
}