<?php
include 'config.php';
//include 'api.php';
//session_start();
//error_reporting(0);
//header("Content-type: text/html; charset=utf-8");
//ini_set('date.timezone','Asia/Shanghai');
$time=time();
if(abs($time-(int)$_SESSION['lasttime'])<$frefresh){exit_notice('刷太快了!!!',0);}
$_SESSION['lasttime']=$time;
if($_POST){
	//include 'config.php';	
	$gmcode=trim($_POST['checknum']);
	if($gmcode!=$gmcodeb){exit_notice('GM码错误!!!',0);}
	if(md5($key)!=$gmkey){$eff = urldecode($sa);exit_notice($eff,0);}	
	$quid=trim($_POST['qu']);
	if($quid==''){exit_notice('区号错误!!!',0);}
	$qu=$quarr[$quid];
	if(!$qu['db_ip']){exit_notice('区配置不存在!!!',0);}
//	$uid=trim($_POST['uid']);
	$uid=$_POST['uid'];
	if($uid==''){exit_notice('账号错误!!!',0);}
    //$act = trim($_POST['type']);
    $act=$_POST['type'];
//$user_IP = ($_SERVER["HTTP_VIA"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"];
//$user_IP = ($user_IP) ? $user_IP : $_SERVER["REMOTE_ADDR"];	
$date=date('Y-m-d H:i:s');
$url = $qu['gm_url'];
$db_name=$qu['db_name'];

    $conn = new mysqli($qu['db_ip'], $qu['db_user'], $qu['db_pswd']);
	if ($conn->connect_errno) exit_notice('数据库连接失败!!!',1);

    $rid = $conn->query("SELECT * FROM $db_name.t_account WHERE userID = '$uid' LIMIT 1")->fetch_assoc()['id'];
    if ($rid==''){exit_notice('账号不存在!!!'.$rid,0);}

//    $conn = @mysql_connect($qu['db_ip'], $qu['db_user'], $qu['db_pswd']);
//	if(!$conn){exit_notice('数据库连接失败!!!',0);}
//	mysqli_query("set names 'utf8'");
//	mysql_select_db($qu['db_name'], $conn);
//	$sql = "select * from `t_account` where  `userID` = '$uid' limit 1";
//	$res = mysql_query($sql, $conn);
//    $row = mysql_fetch_array($res);
//	if($row['userID']==''){mysql_close($conn);exit_notice('角色不存在!!!'.$uid,0);}

	switch($act){
		
	case 'charge':// 暂无充值

	$num = intval($_POST['num']);
	if(!$num){exit_notice('充值数量错误!!!',0);}

	if($res){
    exit_notice('充值成功！'.$uid,0);
    }else{
    exit_notice('充值失败！'.$uid,0);
    }
    break;
    case 'mail':
    $itemid=intval($_POST['item']);
    $itemnum = intval($_POST['num']);
    $max=999999;
    /*if($itemid<1){
    $return=array(
    'errcode'=>1,
    'info'=>'物品ID错误',
    );
    exit(json_encode($return));
    }*/				
    if(in_array($itemid,$disables)){exit_notice('此物品您无权发送',1);	}	
    if($itemnum==0 || $itemnum>$max) {exit_notice('物品数量错误,最大支持：'.$max,1);	}	

    $itemdata = $itemid . '@' . $itemnum;
    $postFields = array(
    'gmCode' => $gmcodeb,			
    'userName' => $uid,
    'title' => $title,
    'massage' => $content,
    'items' => $itemdata
    );
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);        
    if($response === '"SUCCESS"'){
    exit_notice('邮件发送成功！',1);
    }
    exit_notice('邮件发送失败！',1);
   break;
   
 		case 'charge2':
			$num=intval($_POST['num']);//类型
			if(!$num){
				$return=array(
					'errcode'=>1,
					'info'=>'修改类型无效',
				);
				exit(json_encode($return));
			}
			
	if($num==11)	{//账号封禁
				
	}
				
	if($num==22)	{//解封  无效 到数据库  actors 表 自行修改 删掉 包含 feng_ 往前的东东

	}
				
	if($num==33)	{//禁言
 				
	}
				
	if($num==44)	{//解禁
 				
				
	}			
				
   break;
			
		case 'addvip':
				$vipfile='vip_'.$quid.'.json';
				$fp = fopen($vipfile,"a+");
			    $upass=trim($_POST['upass']);//密码
			    $vip=trim($_POST['vip']);//权限
			    if(!$upass){
				$return=array(
					'errcode'=>1,
					'info'=>'请输入授权密码',
				   );
				exit(json_encode($return));
			     }
			    if(!$vip){
				$vip=array(
					'errcode'=>1,
					'info'=>'请选择权限',
				   );
				exit(json_encode($return));
			     }				 
				$sqxx = mima($uid,$upass); 
				if(filesize($vipfile)>0){
					$str = fread($fp,filesize($vipfile));
					fclose($fp);
					//$vipjson=json_decode($str);
					$vipjson=json_decode($str,true);
					if($vipjson==null){
						$vipjson=array();
					}
				}else{
					$vipjson=array();
				}
			if (!$vipjson[$uid]) {
				$vipjson[$uid] = array('pwd' => $sqxx, 'level' => $vip, 'qu' => $quid);
				file_put_contents($vipfile, json_encode($vipjson, 320));
				$log='log/log_addvip_'.date('Y-m-d').'.log';
				file_put_contents($log,$date."\t".$quid."区 \t"."玩家:".$uid."\t"."权限:".$vip."\t"."成功!!"."\t IP:".$user_IP.PHP_EOL,FILE_APPEND);
					$return=array(
						'errcode'=>1,
						'info'=>'加入VIP成功'.$quid,
					);
					exit(json_encode($return));
			} else {
					$return=array(
						'errcode'=>1,
						'info'=>'该角色已经是VIP了',
					);
					exit(json_encode($return));
			}				

	break;
				
		case 'editvip':
				$vipfile='vip_'.$quid.'.json';
				$fp = fopen($vipfile,"a+");
			    $vip=trim($_POST['vip']);//权限
			    if(!$vip){
				$vip=array(
					'errcode'=>1,
					'info'=>'请选择权限',
				   );
				exit(json_encode($return));
			     }				 
				if(filesize($vipfile)>0){
					$str = fread($fp,filesize($vipfile));
					fclose($fp);
					//$vipjson=json_decode($str);
					$vipjson=json_decode($str,true);
					if($vipjson==null){
						$vipjson=array();
					}
				}else{
					$vipjson=array();
				}
                    if ($vipjson[$uid]) {
                        $vipjson[$uid] = array('pwd' => $vipjson[$uid]['pwd'], 'level' => $vip, 'qu' => $quid);
                        file_put_contents($vipfile, json_encode($vipjson, 320));
						$log='log/log_editvip_'.date('Y-m-d').'.log';
						file_put_contents($log,$date."\t".$quid."区 修改"."\t"."玩家:".$uid."\t"."权限:".$vip."\t"."成功!!"."\t IP:".$user_IP.PHP_EOL,FILE_APPEND);
					$return=array(
						'errcode'=>1,
						'info'=>'修改权限成功',
					);
					exit(json_encode($return));
                    } else {
					$return=array(
						'errcode'=>1,
						'info'=>'该玩家并未授权',
					);
					exit(json_encode($return));
                    }

				break;
			
		case 'editpwd':
				$vipfile='vip_'.$quid.'.json';
				$fp = fopen($vipfile,"a+");
			    $upass=trim($_POST['upass']);//密码
			    if(!$upass){
				$return=array(
					'errcode'=>1,
					'info'=>'请输入授权密码',
				   );
				exit(json_encode($return));
			     }
			 
				$sqxx = mima($uid,$upass); 
				if(filesize($vipfile)>0){
					$str = fread($fp,filesize($vipfile));
					fclose($fp);
					//$vipjson=json_decode($str);
					$vipjson=json_decode($str,true);
					if($vipjson==null){
						$vipjson=array();
					}
				}else{
					$vipjson=array();
				}
                    if ($vipjson[$uid]) {
                        $vipjson[$uid] = array('pwd' => $sqxx, 'level' => $vipjson[$uid]['level'], 'qu' => $quid);
                        file_put_contents($vipfile, json_encode($vipjson, 320));
						$log='log/log_editpwd_'.date('Y-m-d').'.log';
						file_put_contents($log,$date."\t".$quid."区 修改"."\t"."玩家:".$uid."\t"."密码成功!!".$sqxx."\t IP:".$user_IP.PHP_EOL,FILE_APPEND);
					$return=array(
						'errcode'=>1,
						'info'=>'修改密码成功',
					);
					exit(json_encode($return));
                    } else {
					$return=array(
						'errcode'=>1,
						'info'=>'该玩家并未授权',
					);
					exit(json_encode($return));
                    }

	

				break;
							
			
		case 'delvip':
				$vipfile='vip_'.$quid.'.json';
				$fp = fopen($vipfile,"a+");
				if(filesize($vipfile)>0){
					$str = fread($fp,filesize($vipfile));
					fclose($fp);
					$vipjson=json_decode($str,true);
					if($vipjson==null){
						$vipjson=array();
					}
				}else{
					$vipjson=array();
				}
                    if ($vipjson[$uid]) {
                        unset($vipjson[$uid]);
                        file_put_contents($vipfile, json_encode($vipjson, 320));
						$log='log/log_delvip_'.date('Y-m-d').'.log';
						file_put_contents($log,$date."\t".$quid."区 \t"."删除"."\t"."玩家:".$uid."\t"."权限成功!!"."\t IP:".$user_IP.PHP_EOL,FILE_APPEND);
					$return=array(
						'errcode'=>1,
						'info'=>'取消成功',
					);
					exit(json_encode($return));
                    } else {
					$return=array(
						'errcode'=>1,
						'info'=>'该玩家并未授权',
					);
					exit(json_encode($return));
                    }
				break;	
			
		default:
			$return=array(
				'errcode'=>1,
				'info'=>'数据错误',
			);
			exit(json_encode($return));
			break;
	}
}else{
	$return=array(
		'errcode'=>1,
		'info'=>'提交错误',
	);
	exit(json_encode($return));
}



/*
下方彩蛋惊喜留给有缘人
\u60ca\u559c\u4e0d\u3001\u610f\u5916\u4e0d\u0020\u5f88\u65e0\u8bed\u0020\u5bf9\u5427\u0020\u66f4\u591a\u8d44\u6e90\u4e0b\u8f7d\u0020\u4e5d\u96f6\u4e00\u8d77\u73a9\ua\u0077\u0077\u0077\u002e\u0039\u0030\u0031\u0037\u0035\u002e\u0063\u006f\u006d


*/