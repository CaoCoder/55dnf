/*
 Navicat Premium Data Transfer

 Source Server         : centosdnf
 Source Server Type    : MySQL
 Source Server Version : 50744
 Source Host           : 8.130.124.74:3306
 Source Schema         : login

 Target Server Type    : MySQL
 Target Server Version : 50744
 File Encoding         : 65001

 Date: 25/06/2024 23:28:30
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sys_agent
-- ----------------------------
DROP TABLE IF EXISTS `sys_agent`;
CREATE TABLE `sys_agent`  (
  `agent_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'agent_id',
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `agentId` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'agent_id',
  PRIMARY KEY (`agent_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_agent
-- ----------------------------

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'user_id',
  `login_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `userId` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'user_id',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user
-- ----------------------------

-- ----------------------------
-- Table structure for t_account
-- ----------------------------
DROP TABLE IF EXISTS `t_account`;
CREATE TABLE `t_account`  (
  `userID` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `passwd` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `isStop` tinyint(1) NULL DEFAULT NULL,
  `privilege` tinyint(16) NULL DEFAULT 0,
  `id` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `score` int(32) NOT NULL,
  `channelNo` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `regDate` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `agent_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `username_index`(`userID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_account
-- ----------------------------
INSERT INTO `t_account` VALUES ('aa123456', '123456', 0, 0, '1737745492525711360', 0, '111', '20231221', '', '2023-12-21 16:03:06');
INSERT INTO `t_account` VALUES ('sa123', '123456', 0, 0, '1739251440530292736', 0, '111', '20231225', '', '2023-12-25 19:47:12');
INSERT INTO `t_account` VALUES ('90gm123', '123456', 0, 0, '1739623746320408576', 0, '111', '20231226', '', '2023-12-26 20:26:36');
INSERT INTO `t_account` VALUES ('123456', '123456', 0, 0, '1805621572540985344', 0, '111', '20240625', '', '2024-06-25 23:18:24');

-- ----------------------------
-- Table structure for t_channel
-- ----------------------------
DROP TABLE IF EXISTS `t_channel`;
CREATE TABLE `t_channel`  (
  `channelNo` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '渠道号',
  `parentChannel` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '父渠道',
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '密码',
  `auth` tinyint(1) NULL DEFAULT NULL COMMENT '是否总代',
  `point` int(11) NULL DEFAULT NULL COMMENT '剩余点数',
  PRIMARY KEY (`channelNo`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_channel
-- ----------------------------
INSERT INTO `t_channel` VALUES ('111', '11', '123456', 1, 100000);

-- ----------------------------
-- Table structure for t_gm_log
-- ----------------------------
DROP TABLE IF EXISTS `t_gm_log`;
CREATE TABLE `t_gm_log`  (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `server_id` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '服务器ID',
  `target_account` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'gm命令目标账户',
  `gm_command` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'gm命令类型',
  `gm_param` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'gm命令参数',
  `status` int(11) NULL DEFAULT NULL COMMENT '操作状态',
  `create_time` datetime NULL DEFAULT NULL COMMENT '操作时间',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_gm_log
-- ----------------------------

-- ----------------------------
-- Table structure for t_invite
-- ----------------------------
DROP TABLE IF EXISTS `t_invite`;
CREATE TABLE `t_invite`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `inviteCode` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `channelNo` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `state` smallint(6) NOT NULL DEFAULT 0,
  `createTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_invite
-- ----------------------------

-- ----------------------------
-- Table structure for t_order
-- ----------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `orderId` bigint(20) NULL DEFAULT NULL COMMENT '内部订单ID',
  `tradeNo` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '第三方订单ID',
  `serverId` int(11) NULL DEFAULT NULL,
  `accountId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `commodityId` int(11) NULL DEFAULT NULL,
  `commodityName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '支付方式',
  `money` double NULL DEFAULT NULL,
  `status` int(255) NULL DEFAULT NULL,
  `agentId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `createTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `id`(`id`, `orderId`, `serverId`, `accountId`, `commodityId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_order
-- ----------------------------

-- ----------------------------
-- Table structure for t_server
-- ----------------------------
DROP TABLE IF EXISTS `t_server`;
CREATE TABLE `t_server`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '服务器ID',
  `server_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '服务器名称',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '服务器IP',
  `port` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '服务器端口',
  `gm_port` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'gm端口',
  `open_status` int(1) NULL DEFAULT NULL COMMENT '开启状态 0:关闭,1:开启',
  `congestion` int(11) NULL DEFAULT NULL COMMENT '拥挤',
  `recommend` int(11) NULL DEFAULT NULL COMMENT '推荐',
  `creatable` int(11) NULL DEFAULT NULL COMMENT '可以创造',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_server
-- ----------------------------
INSERT INTO `t_server` VALUES (1, '小曹dnf', '8.130.124.74', '10001', NULL, 0, NULL, NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
